let firstNumber = +prompt('Enter first number');
let secondNumber = +prompt('Enter second number');
let sum = firstNumber + secondNumber;
alert(`The sum is ${sum}`);